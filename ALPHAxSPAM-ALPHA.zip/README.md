<p align="center">
  <img src="./resources/logo.jpg" alt="RiZoeLXSpam Logo">
</p>
<h1 align="center">
  <b>ᴀʟᴘʜᴀ X sᴘᴀᴍ</b>
</h1>

[![Forks](https://img.shields.io/github/forks/MrRizoel/RiZoeLXSpam?style=flat-square&color=orange)](https://github.com/MrRizoel/RiZoeLXSpam/fork)
[![Python](https://img.shields.io/badge/Python-v3.9.7-blue)](https://www.python.org/)
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/MrRizoel/RiZoeLXSpam)   
----
 
- [x] ☯︎ ғᴀsᴛ ᴀɴᴅ sᴛᴀʙʟᴇ ☯︎
- [x] Deploy upto 40 UserBots in One time 🔥
- [x] Dm Spam / Raid
- [x] Pornspam
- [x] You can also add members using Spam Bots


### Generate string session from below:

[![GenerateString](https://img.shields.io/badge/RiZoeLXSpam-String-yellowgreen)](https://replit.com/@RiZoeL/RiZoeLXSpam#main.py) ``Telethon``

# Deploy on heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/MrRizoel/XSpam-Deploy)


# ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅs
[![Commands](https://img.shields.io/badge/RiZoeLXSpam-CMDS-blue)](https://t.me/Resourcez/4)

# Support & Updates
* [Channel](https://t.me/Noob_Hacker_OP)
* [Support Group](https://t.me/noob_public_chat)

# Credits
* [RiZoeL Creator](https://github.com/MrRizoel)
* [Lonami](https://github.com/LonamiWebs/) for [Telethon.](https://github.com/LonamiWebs/Telethon)
